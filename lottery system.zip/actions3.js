temp = "";
flag = 0;
count = "";
results = [];
sr = 0;
dt = new Date().toString();
odd_res = "";
eve_res = "";
tot_odd = 0;
tot_eve = 0;
win = "";
finArray = [];
lsArray = [];
var oddAtEnd = 0;
var evenAtEnd = 0;
winsAtEnd = 0;
drawAtEnd = 0;
evenWinAtEnd = 0;
oddWinAtEnd = 0;


function takeInp(event) {
    if (event.keyCode == 13) {

        if (document.getElementById('inp1').value <= 59 && document.getElementById('inp1').value >= 1) {
            temp = document.getElementById("inp1").value;
            document.getElementById("inp1").value = "";

            for (var i = 0; i < 6; i++) {
                if (document.getElementById(`gb${i}`).value != "") {
                    continue;
                }
                else {
                    document.getElementById(`gb${i}`).value = temp;
                    break;
                }
            }
        }
        else { alert("Please Enter a value between 1 and 59"); }
    }
}

function subfor1() {

    for (var i = 0; i < 6; i++) {
        if (document.getElementById(`gb${i}`).value != "" && document.getElementById(`gb${i}`).value >= 1 && document.getElementById(`gb${i}`).value <= 59) {
            results.push(document.getElementById(`gb${i}`).value);
            document.getElementById(`gb${i}`).value = "";
        }
        else { alert("Don't Manipulate the values"); }
    }
    // alert("Entered Results Successfully added to results Array");
}

function countInd() {
    subfor1();
    if (localStorage.getItem('lsArray')) {
        lsArray = localStorage.getItem('lsArray');
        lsArray = JSON.parse(lsArray);
        count = lsArray.length;
    }
    else {
        count = "";
    }
}


function prepareToSet() {

    odd_res = "";
    eve_res = "";
    tot_odd = 0;
    tot_eve = 0;

    //set the value of serial NO
    countInd();
    sr = count + 1;
    //calculating total odd results (values)
    for (i = 0; i < results.length; i++) {
        if (results[i] % 2 != 0)
            odd_res = odd_res + " " + results[i];
    }

    //calculating total even results (values)
    for (i = 0; i < results.length; i++) {
        if (results[i] % 2 == 0)
            eve_res = eve_res + " " + results[i];
    }

    //calculating NO of total odd results
    for (i = 0; i < results.length; i++) {
        if (results[i] % 2 != 0)
            tot_odd += 1;
    }
    //calculating NO of total even results
    for (i = 0; i < results.length; i++) {
        if (results[i] % 2 == 0)
            tot_eve += 1;
    }
    // calculating wins
    if (tot_odd > tot_eve) {
        win = "odd";
    }
    else if (tot_eve > tot_odd) {
        win = "even";
    }
    else {
        win = "draw";
    }

}


function setToLocal() {
    prepareToSet();

    finArray = [sr, dt, results, odd_res, eve_res, tot_odd, tot_eve, win];
    lsArray.push(finArray);
    lsArray = JSON.stringify(lsArray);
    localStorage.setItem('lsArray', lsArray);
    alert("Data Successfully Added");
    location.reload();
}

function toTable() {
    if (localStorage.getItem('lsArray')) {
        lsArray = JSON.parse(localStorage.getItem('lsArray'));
        // console.log(finArray);
        for (var i = 0; i < lsArray.length; i++) {
            finArray = lsArray[i];
            let row = "<tr>";
            for (var j = 0; j < finArray.length; j++) {
                row += `<td>${finArray[j]}</td>`;
            }
            row += "</tr>";
            document.getElementById("tBody").innerHTML += row;
        }
    }
}

function stats() {
    if (localStorage.getItem('lsArray')) {
        lsArray = JSON.parse(localStorage.getItem('lsArray'));
        // console.log(finArray);
        for (var i = 0; i < lsArray.length; i++) {
            finArray = lsArray[i];
            oddAtEnd = oddAtEnd + parseInt(finArray[5]);
            evenAtEnd = evenAtEnd + parseInt(finArray[6]);

            if (finArray[7] == 'odd') {
                oddWinAtEnd = oddWinAtEnd + 1;
            }
            else if (finArray[7] == 'even') {
                evenWinAtEnd = evenWinAtEnd + 1;
            }
            else if (finArray[7] == 'draw') {
                drawAtEnd = drawAtEnd + 1;
            }

        }
        command =  `<td>${oddAtEnd}</td><td>${evenAtEnd}</td><td>${evenWinAtEnd}</td><td>${oddWinAtEnd}</td><td>${drawAtEnd}</td>`;
        document.getElementById("forStats").innerHTML = command;

    }
}

stats();
toTable();