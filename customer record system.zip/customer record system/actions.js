arr = [];
var flag = 0;

function formVisible() {
    document.getElementById("menu").style.display = "none";
    document.getElementById("form1").style.display = "contents";
}

function formInVisible() {
    document.getElementById("menu").style.display = "initial"
    document.getElementById("form1").style.display = "none";
    document.getElementById("table1").style.display = "none";
}

function pushData() {
    if(flag){
        update(flag);
    }else{
        var name = document.getElementById("name").value;
        var age = document.getElementById("age").value;
        var contact = document.getElementById("contact").value;
        var email = document.getElementById("email").value;

        obj = { name, age, contact, email };
        arr.push(obj);
        let users = JSON.stringify(arr);
        localStorage.setItem("users", users);
        alert("Data Added Successfully");

        document.getElementById("name").value = "";
        document.getElementById("age").value = "";
        document.getElementById("contact").value = "";
        document.getElementById("email").value = "";
        formInVisible();
    }
}

function fetchData(){
    let users = localStorage.getItem("users");
    arr = JSON.parse(users);
}

function displayRecord() {
    document.getElementById("menu").style.display = "none";
    document.getElementById("table1").style.display = "initial";

    let users = localStorage.getItem("users");
    if (users) {
        arr = JSON.parse(users);
        let table = '';
        for (var i = 0; i < arr.length; i++) {
            table += `<tr>`;
            table += `<td>${arr[i].name}</td>`;
            table += `<td>${arr[i].age}</td>`;
            table += `<td>${arr[i].contact}</td>`;
            table += `<td>${arr[i].email}</td>`;

            table += `<td><button id="${i}" onclick="editData(${i})" >Edit</button> <button id="${i}" onclick='removeData(${i})'>Delete</button></td>`;
            table += `</tr>`;

            //document.getElementById('i').addEventListener("click",removeData(i));
        }
        document.getElementById('tablebody').innerHTML = table;
    }
}

function removeData(i) {
    let users = JSON.parse(localStorage.getItem('users'));
    users.splice(i, 1);
    localStorage.setItem('users', JSON.stringify(users));
    alert("Data Successfully Deleted");
    displayRecord();
}

function editData(i) {
    document.getElementById("table1").style.display = "none";
    document.getElementById("form1").style.display = "initial";

    users = JSON.parse(localStorage.getItem('users'));
    user = users[i];

    document.getElementById("name").value = user.name;
    document.getElementById("age").value = user.age;
    document.getElementById("contact").value = user.contact;
    document.getElementById("email").value = user.email;
    flag = i;
    //document.getElementById("submit").addEventListener("click",update);
    //document.getElementById("submit").onclick = update();
}

function update(i) {
    arr[i].name = document.getElementById("name").value;
    arr[i].age = document.getElementById("age").value;
    arr[i].contact = document.getElementById("contact").value;
    arr[i].email = document.getElementById("email").value;

    localStorage.setItem('users', JSON.stringify(arr));

    alert("Data Successfully Edited");
    flag = 0;
    displayRecord();
}

function clearStorage() {
    localStorage.clear();
    alert("local storge cleared successfully");
}

fetchData();