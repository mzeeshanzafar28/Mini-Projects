<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home Page</title>
</head>

<body style="background-color: royalblue">
    <h1>Home Page @ Employee Record System</h1>
    <h3>Select an Option : </h3>
    <a href="/addEmployee"><button style="float: left;background-color:cadetblue">Add Employee</button></a>
    <br><br>
<div style="display:flex">

    <table border="1">
        <thead>
            <tr>
                <th colspan='7'>Total Record in Database</th>
            </tr>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Contact</th>
                <th>Salary</th>
                <th>D-ID</th>
                <th>Designation</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if(@isset($data)): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> <?php echo e($data->id); ?> </td>
                        <td> <?php echo e($data->name); ?> </td>
                        <td> <?php echo e($data->contact); ?> </td>
                        <td> <?php echo e($data->salary); ?> </td>
                        <td> <?php echo e($data->did); ?> </td>
                        <td> <?php echo e($designations[$data->id]); ?> </td>
                        <td> <a href="/edit/<?php echo e($data->id); ?>"><button
                                    style="background-color:cadetblue">Edit</button></a>
                            <a href="/del/<?php echo e($data->id); ?>"><button
                                    style="background-color:cadetblue">Delete</button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>

   
</div>

</body>

</html>
<?php /**PATH F:\Codes\proj2\resources\views/welcome.blade.php ENDPATH**/ ?>