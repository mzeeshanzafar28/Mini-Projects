<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>employeeEntry</title>
</head>
<body style="background-color:darkcyan">
    <form action="/sub" method="POST">
        <?php echo csrf_field(); ?>
        <label>Name</label> <input type="text" placeholder="Enter Your Name Here" name="name" value="<?php echo e($data->name ?? ''); ?>">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <br>   <div style="color:darkred"> <?php echo e($message); ?> </div>    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <br>
        <label>Contact</label> <input type="text" placeholder="Enter Your Contact Here" name="contact" value="<?php echo e($data->contact ?? ''); ?>">
        <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <br>   <div style="color:darkred"> <?php echo e($message); ?> </div>    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        

        
        <br>
        <label>Designation</label> <select name="designation" value="">
            <?php $__currentLoopData = $des; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($d->id); ?>"><?php echo e($d->designation); ?></option>
            <label type="hidden" name="dname" value="<?php echo e($d->designation); ?>"></label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <br>   <div style="color:darkred"> <?php echo e($message); ?> </div>    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <br>
        <label>Salary</label> <input type="text" placeholder="Enter Your Salary Here" name="salary" value="<?php echo e($data->salary ?? ''); ?>">
        <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <br>   <div style="color:darkred"> <?php echo e($message); ?> </div>    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        
        <br>
        <input type="submit" value="Submit">
    </form>


</body>
</html><?php /**PATH F:\Codes\proj2\resources\views/addEmployee.blade.php ENDPATH**/ ?>