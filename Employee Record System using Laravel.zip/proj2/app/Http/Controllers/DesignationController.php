<?php

namespace App\Http\Controllers;

use App\Models\DesignationModel;
use Illuminate\Http\Request;

class DesignationController extends Controller
{
    function setDes(){
        $das = DesignationModel::all();
        return view('addEmployee')->with('des', $das);

    }
}
