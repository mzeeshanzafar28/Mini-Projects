<?php

namespace App\Http\Controllers;

use App\Models\EmployeeModel;
use App\Models\DesignationModel;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    function subData(Request $re){
        $re->validate([
            'name'=>'required',
            'contact'=>'required',
            'salary'=>'required',
            'designation'=>'required'

        ]);

        $data = new EmployeeModel();
        $data->name = $re->name;
        $data->contact = $re->contact;
        $data->salary = $re->salary;
        $data->did = $re->designation;
        $data->designation = "";
        $data->save();
        // return view('welcome');
        return redirect('home');

    }

    function retData(){
        $data = new EmployeeModel();
        $data = $data->all();
        $designations = [];
        foreach($data as $record){
            $designation = DesignationModel::find($record->did)->designation;
            $designations[$record->id] = $designation;
        }
        return view('welcome', get_defined_vars());
    }

    function delData($id){

        EmployeeModel::find($id)->delete();
        return redirect('/');

    }

    function editData($id){

        $data = EmployeeModel::find($id);
        $des = DesignationModel::all();
        // dd($data->toArray());
        EmployeeModel::find($id)->delete();
        return view('addEmployee',get_defined_vars());


    }


}
