<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>employeeEntry</title>
</head>
<body style="background-color:darkcyan">
    <form action="/sub" method="POST">
        @csrf
        <label>Name</label> <input type="text" placeholder="Enter Your Name Here" name="name" value="{{ $data->name ?? '' }}">
        @error('name')   <br>   <div style="color:darkred"> {{$message}} </div>    @enderror
        
        <br>
        <label>Contact</label> <input type="text" placeholder="Enter Your Contact Here" name="contact" value="{{ $data->contact ?? '' }}">
        @error('contact')   <br>   <div style="color:darkred"> {{$message}} </div>    @enderror
        

        {{-- @dd($des) --}}
        <br>
        <label>Designation</label> <select name="designation" value="">
            @foreach ($des as $d)
            <option value="{{ $d->id }}">{{ $d->designation }}</option>
            <label type="hidden" name="dname" value="{{ $d->designation  }}"></label>
            @endforeach
        </select>
        @error('designation')   <br>   <div style="color:darkred"> {{$message}} </div>    @enderror


        <br>
        <label>Salary</label> <input type="text" placeholder="Enter Your Salary Here" name="salary" value="{{ $data->salary ?? '' }}">
        @error('salary')   <br>   <div style="color:darkred"> {{$message}} </div>    @enderror
        
        
        <br>
        <input type="submit" value="Submit">
    </form>


</body>
</html>