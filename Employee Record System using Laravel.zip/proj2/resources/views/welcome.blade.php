<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home Page</title>
</head>

<body style="background-color: royalblue">
    <h1>Home Page @ Employee Record System</h1>
    <h3>Select an Option : </h3>
    <a href="/addEmployee"><button style="float: left;background-color:cadetblue">Add Employee</button></a>
    <br><br>
<div style="display:flex">

    <table border="1">
        <thead>
            <tr>
                <th colspan='7'>Total Record in Database</th>
            </tr>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Contact</th>
                <th>Salary</th>
                <th>D-ID</th>
                <th>Designation</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @if (@isset($data))
                @foreach ($data as $data)
                    <tr>
                        <td> {{ $data->id }} </td>
                        <td> {{ $data->name }} </td>
                        <td> {{ $data->contact }} </td>
                        <td> {{ $data->salary }} </td>
                        <td> {{ $data->did }} </td>
                        <td> {{ $designations[$data->id] }} </td>
                        <td> <a href="/edit/{{ $data->id }}"><button
                                    style="background-color:cadetblue">Edit</button></a>
                            <a href="/del/{{ $data->id }}"><button
                                    style="background-color:cadetblue">Delete</button></a>
                        </td>
                    </tr>
                @endforeach
            @endif
        </tbody>
    </table>

   
</div>

</body>

</html>
