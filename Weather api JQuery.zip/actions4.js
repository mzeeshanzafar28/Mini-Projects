$(document).ready(function () {
    clear();
    $("#search").click(function () {
        city_name = $("#city").val();
        API_KEY = "e50122be81b5a14a8f548192775d1302";
        $.ajax({
            url: "http://api.openweathermap.org/data/2.5/weather?q=" + city_name + "&appid=" + API_KEY,
            dataType: "json",
            success: function (data) {
                console.log(data);
                $("#inp1").val(JSON.stringify(data.weather[0].description));
                $("#inp2").val(JSON.stringify(data.main.temp -  273.15 + "°С"));
                $("#inp3").val(JSON.stringify(data.clouds.all));
                $("#inp4").val(JSON.stringify(data.sys.country));
                $("#inp5").val(data.name);
                $("#inp6").val(data.timezone);
                $("#inp7").val(data.visibility);
                $("#inp8").val(data.coord.lon);
                $("#inp9").val(data.coord.lat);
                $("#inp10").val(data.main.humidity);
                $("#inp11").val(data.wind.speed);
                $("#inp12").val(data.wind.deg);
                $("#city").val("");
            }
        });
    });
});

$(document).ready(function () {
    $("#city").keypress(function (e) {
        if (e.which == 13) {
            $("#search").click();
        }
    })
});

function clear(){
    for (var i=1; i<13; i++){
        let id = "#inp" + i;
        $(id).val("");
    }

}